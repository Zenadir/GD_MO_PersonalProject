﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DayNightCycle : MonoBehaviour {

	//Eventually this should load from a save file, setting the rotation of the sun at the beginning. 
	int globalTimer;

	//Number of seconds for the sun to make a full rotation.
	public const float ORBIT_TIME = 30f;
	// Use this for initialization

	enum SunColors{ Test1, Test2, Test3, Final};
	SunColors CurrentColor;


	bool DayTime;
	int CurrentDay;

	Light Sunlight;


	//These will be obselete shortly
	Color StartColor;
	Color NightColor;

	float ColorLerpExperiment = .50f;

	void Awake(){
		
		Application.targetFrameRate = 60;
	}
	void Start () {
		//globalTimer = 0;
		Sunlight = GetComponent<Light>();
		StartColor = Sunlight.color;
		NightColor = Color.blue;
		DayTime = true;
		CurrentColor = SunColors.Test1;



		//This should eventually load from the save file.
		CurrentDay = 0;
	}
	
	// Update is called once per frame
	void FixedUpdate () {

		//Debug.Log (globalTimer / 50);

		++globalTimer;

		transform.RotateAround (Vector3.zero, Vector3.up, (360/ORBIT_TIME)/50);

		//Unity runs at 50fps, not 60. Every 50 frames is 1 second. 

		if (DayTime == true) {
			Sunlight.color = Color.Lerp (StartColor, NightColor, (globalTimer / 50f) / (ORBIT_TIME / 2f));
		}
			

		if (DayTime == false){

			Sunlight.color = Color.Lerp (NightColor, StartColor, (globalTimer / 50f) / (ORBIT_TIME / 2f));

		}


		if (Sunlight.color == NightColor && DayTime == true) {
			DayTime = false;
			globalTimer = 0;
		}
		if(Sunlight.color == StartColor && DayTime == false)
		{
			DayTime = true;
			globalTimer = 0;
			++CurrentDay;
		}
			


	
	}
}
