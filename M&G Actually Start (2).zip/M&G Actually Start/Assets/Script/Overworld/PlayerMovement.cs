﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}

	// Update is called once per frame
	void Update () {
		//Subtract rotation from vector3.up

		if (Input.GetKey (KeyCode.A)) 
		{
			transform.Rotate (0, 1, 0);
		}
		if (Input.GetKey (KeyCode.D)) 
		{
			transform.Rotate (0, -1, 0);
		}
			

	}
}
