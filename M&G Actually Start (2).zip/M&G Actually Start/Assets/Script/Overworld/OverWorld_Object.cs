﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OverWorld_Object : MonoBehaviour {

	//Used To load the apropriate scene
	string LocationName;
	enum EnemyNames { E1,E2,E3 };

	int EnemyQuantity;

	enum SunModifier { S1, S2, S3 }


	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void Generate(){

		//instantiate(EnemyName(
	}
}
