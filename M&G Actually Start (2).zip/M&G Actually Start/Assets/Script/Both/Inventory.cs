﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Inventory : MonoBehaviour {

	int Coins = 0;


	Dictionary<GameObject,int> consumables;

	List<GameObject> weapons;

	void Awake()
	{
		DontDestroyOnLoad (gameObject);
	}

	void Start () {
		//Load data here
		weapons = new List<GameObject>();
	}

	// Update is called once per frame
	void Update () {
		
	}

	public void AddCoin(GameObject coin)
	{
			++Coins;
		DestroyImmediate(coin);
		Debug.Log ("Coins: " + Coins);
	}

	void AddConsumable(GameObject pickup)
	{	
		if(consumables.ContainsKey(pickup))
			{
				consumables[pickup]++;
			}
	}

	public void AddWeapon(GameObject weap)
	{
		weapons.Add (weap);
		Debug.Log ("Obtained " + weap.name);
		DestroyImmediate (weap);
	}
}
