﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FPSRotation : MonoBehaviour {
	public float  PercentMouseRange = .05f;
	float MouseX;
	const int MAX_ROTATION = 10;
	int CurrentRotation = 0;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		MouseX = Input.mousePosition.x / Screen.width;

		if (MouseX < PercentMouseRange && CurrentRotation <MAX_ROTATION) {
			transform.Rotate (new Vector3 (0, -3f, 0));
			++CurrentRotation;

		}

		if (MouseX > 1f - PercentMouseRange && CurrentRotation > -MAX_ROTATION) {
			transform.Rotate (new Vector3 (0, 3f, 0));
			--CurrentRotation;
		}

	}
}
