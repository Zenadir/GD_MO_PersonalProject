﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Coin : MonoBehaviour {
	int riseTime;
	Rigidbody coinBod;

	// Use this for initialization
	void Start () {
		riseTime = 500;
		coinBod = transform.GetComponent<Rigidbody> ();
		coinBod.AddForce (Vector3.up * 5);
		transform.localRotation = Quaternion.Euler (Random.Range (0, 360), Random.Range (0, 360), Random.Range (0, 360));

	}
	
	// Update is called once per frame
	void Update () {
		while (riseTime > 0) {
			riseTime--;
			if (riseTime % 3 == 0) {
				coinBod.AddForce( new Vector3(Random.Range(-10f,10f), Mathf.Lerp(6,2,riseTime), Random.Range(-10f,10f)));
				coinBod.AddTorque(new Vector3(Random.Range(20, 100),Random.Range(20, 100),Random.Range(20, 100)));
			}

		
		}


	}

	void OnMouseDown()
	{
		GameObject.FindWithTag ("Inventory").GetComponent<Inventory>().AddCoin(gameObject);
	}
}
