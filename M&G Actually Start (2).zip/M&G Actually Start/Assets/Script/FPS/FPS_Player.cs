﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class FPS_Player : MonoBehaviour {


	float escapeFrames;

	public List<Vector3> previousLocations;

	bool escapeLocked = false;


	public float  percentMouseRange = .05f;
	float MouseX;
	const int MAX_ROTATION = 10;
	public int currentRotation = 0;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		Escape ();
		ViewRotation ();
	}

	void Escape (){

		if(Input.GetKeyDown(KeyCode.E))
		{
		escapeFrames = GameObject.FindGameObjectsWithTag ("Enemy").Length * 2.5f *50f;
				
		}

		if (Input.GetKey(KeyCode.E) && escapeLocked == false) 
		{
			--escapeFrames;

			if (escapeFrames <= 0) {

				if (previousLocations.Count == 0) {
					SceneManager.LoadScene ("WorldMap");
				} else {
					transform.position = previousLocations[previousLocations.Count - 1];
						previousLocations.RemoveAt(previousLocations.Count-1);
					transform.localRotation = Quaternion.Euler(Vector3.zero);
					currentRotation = 0;
					escapeLocked = true;
				}

			}
		}


		if(Input.GetKeyUp(KeyCode.E)){
			escapeLocked = false;
		}
			
	
	}

	void ViewRotation()
	{
		MouseX = Input.mousePosition.x / Screen.width;

		if (MouseX < percentMouseRange && currentRotation <MAX_ROTATION) {
			transform.Rotate (new Vector3 (0, -3f, 0));
			++currentRotation;

		}

		if (MouseX > 1f - percentMouseRange && currentRotation > -MAX_ROTATION) {
			transform.Rotate (new Vector3 (0, 3f, 0));
			--currentRotation;
		}

	}

}




