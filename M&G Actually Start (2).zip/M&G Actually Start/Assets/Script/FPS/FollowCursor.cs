﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowCursor : MonoBehaviour {

	Rigidbody2D CursorBod;

	public Texture2D CursorImage;
	// Use this for initialization
	void Start () {
		CursorBod = GetComponent<Rigidbody2D> ();

		Cursor.SetCursor (CursorImage, new Vector2(CursorImage.width/2,CursorImage.height/2), CursorMode.Auto);
	
	}
	
	// Update is called once per frame
	void FixedUpdate () {
		transform.position = Camera.main.ScreenToWorldPoint (Input.mousePosition);
		transform.rotation = Quaternion.Euler (Vector3.zero);

	}


}
