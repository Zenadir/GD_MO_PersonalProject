﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FirstPersonRotation : MonoBehaviour {

	Vector3 LastMousePosition;
	//The max amount of distance the player can look to the left or right.
	float MaxRotation = 25f;
	float CurrentRotation;

	// Use this for initialization
	void Start () {
		LastMousePosition = new Vector3 (Input.mousePosition.x, Input.mousePosition.y);

	}
	
	// Update is called once per frame
	void Update () {

		float difference = Input.mousePosition.x - LastMousePosition.x;

		Debug.Log (LastMousePosition.x);

		if (difference!= 0)
			{	

			if (CurrentRotation + (difference * .2f) < MaxRotation && CurrentRotation + difference > -MaxRotation) {
				
				transform.Rotate (new Vector3 (0, difference * .2f, 0));
				CurrentRotation += difference * .2f;

			}


			}

		LastMousePosition = Input.mousePosition;

	}

}
