﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Door : MonoBehaviour {

	public bool isSceneChanger;

	public string sceneName;

	Vector3 warpLocation;

	GameObject player;

	// Use this for initialization

	void Start () {

		if (isSceneChanger == false) {
			warpLocation = transform.GetChild(0).position;
		}

		player = GameObject.Find ("Player");
	}
	
	// Update is called once per frame
	void Update () {

	}


	//When the player clicks on a door:
	//If its a warping door, Move the player object to the position of the door's warp location.
	//If its a scene loading door, load the apropriate scene, or log an error. 
	void OnMouseDown()
	{
		if (isSceneChanger == false) {

			//Add the players current location to the list of the previous locations
			player.GetComponent<FPS_Player> ().previousLocations.Add (player.transform.position);

			//Move the player to the desired warp location
			player.transform.position = warpLocation;
			player.transform.localRotation= Quaternion.Euler(Vector3.zero);
			player.GetComponent<FPS_Player> ().currentRotation = 0;

		} else {

				try {
				
					SceneManager.LoadScene (sceneName);

				} catch (System.Exception ex) {
				
					Debug.Log (ex.Message);
				}
		
		}
	
	}
		

}
